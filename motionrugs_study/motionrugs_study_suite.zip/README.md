# Motionrugs Evaluation Suite

The MotionRugs study tool consists of a backend and a frontend. Both can be deployed through a k8s-cluster. Manual building is possible, too. Before a cluster deployment, the k8s-config in the .kube-Folder needs to be adapted. The fields needing replacement have been marked accordingly. The k8s-deployment can be handled through the provided gitlab-ci.yml, which also may need to be adapted to your needs.

If you want to edit tasks, this can be done in the motionrugs.db file in the backend folder. The file is a sqlite file that can be opened using DB Browser for sqlite, for example.

## Installation
For manual installation, follow the next steps:
###Frontend

```bash
cd frontend
npm install
```

###Backend

```bash
cd backend
```
Generate the environment. Apart from the Secret, all defaults can be accepted. 

```bash
python make_env.py
# Use dotenv
source .env

# e.g. .venv oder ~/.venv/mr-eval
python3 -m venv PATH_TO_VENV 
source PATH_TO_VENV/bin/activate
pip install -r requirements.txt
```

###Generate / upgrade task database
Necessary if something is changed in the db schema in model.py.
```bash
python manage.py db init # beim ersten mal
python manage.py db migrate
python manage.py db upgrade
```

###Update DB with new tasks

Create/update the tasks.csv file, then reload as below. Beware: Operation is destructive.

```bash
python manage.py reload_tasks
```

### Starting the Development server

Frontend files are located in folder frontend.

```bash
npm start
```

Starting the Flask Backend

```bash
source .env # once
flask run
```

### Production build

```bash
npm run build
```
### 

## License
MIT