import './styles/index.scss';
import '@mdi/font/css/materialdesignicons.min.css';
import bulmaSteps from 'bulma-steps';
import * as d3 from 'd3';
import State from './js/State';


export const baseURL = 'http://localhost:5000/';


global.firstStep = true;
export const statemanager = new State();


function toggleVisibility(selector) {
    document.querySelector(selector).style.display === 'none'
        ? document.querySelector(selector).style.display = ''
        : document.querySelector(selector).style.display = 'none';
}

function toggleStepActions() {
    // find bulma steps and hide
    toggleVisibility('.steps-actions');
    if (global.firstStep) {
        document.querySelector('a[data-nav="next"]').setAttribute('disabled', 'disabled');
        global.firstStep = false;
    } else {
    }
}


function startTask() {
    const el = document.querySelector(`.step-content.is-active>div#explanation-${statemanager.storage.get('step')}`);
    el.style.display = 'none';
    const el2 = document.querySelector(`#task-${statemanager.storage.get('step')}`);
    el2.style = null;
    statemanager.nextTask();
}

document.querySelector('#chk-agree').addEventListener('click', () => toggleVisibility('#agree-button'));
document.querySelector('#btn-submit-form').addEventListener('click', () => document.querySelector('a[data-nav]').dispatchEvent(new MouseEvent('click')));

d3.select('#agree-button').on('click', (d) => {
        toggleVisibility('#explanation-pre');
        toggleVisibility('#form');
        //toggleVisibility('.steps-actions');
    });


function nextStep() {
    const ret = statemanager.next();
    if (ret != 0) return ['Form not valid.'];
    toggleVisibility('.steps-actions');
}


bulmaSteps.attach('.steps', { onShow: toggleStepActions, beforeNext: nextStep, onError: (d) => console.error(d) });

document.querySelectorAll('.start-task').forEach((el) => el.addEventListener('click',
    () => startTask()));
