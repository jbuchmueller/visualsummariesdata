import * as d3 from 'd3';
import VizEval from './VizEval';

export default class SmallMultiplesEval extends VizEval {
    constructor(containerElement) {
        super(containerElement, true);
    }

    attach(viz) {
        this.clear();


        // Event listeners, make responsible and add submission
        window.addEventListener('resize', this.render.bind(this));
        this.toggleAwayListener();


        // Css magic to make the viz wider than its parent body
        this.containerElement.node().style = 'width: 90vw;position: relative;left: 45%;right: 40%;margin-left: -40vw;margin-right: -40vw;';
        this.legend = this.containerElement
            .append('img')
            .attr('src', 'assets/legend.png')
            .attr('style', 'margin-left: auto;margin-right: auto;width: 15%;');

        this.svg = this.containerElement.append('svg').attr('viewBox', '0 0 2000 750').attr('preserveAspectRatio', 'none');

        const cols = 8;
        const edge = 2000 / cols;
        let col = 0;
        let row = 0;

        for (const panel in viz) {
            if (col * edge >= 2000) {
                row++;
                col = 0;
            }
            const g = this.svg.append('g').attr('id', `panel-${row}-${col}`).attr('class', 'panel');
            g.append('image').attr('xlink:xlink:href', viz[panel]).attr('x', col * edge).attr('y',
                row * edge)
                .attr('height', edge)
                .attr('width', edge);
            g.append('rect').attr('x', col * edge + 3).attr('y',
                row * edge + 3).attr('height', edge - 6)
                .attr('class', 'sm-overlay')
                .attr('width', edge - 6)
                .attr('data-panel', `${row}-${col}`)
                .style('pointer-events', 'none')
                .on('click',
                    this.toggleSelected.bind(this));
            col++;
        }


        this.setupStart();
        this.render();
    }



    changeMethod(method) {
        this.taskType = method;
        this.svg.selectAll('.sm-overlay').classed('selected', false);
        this.svg.selectAll('text').remove();
        this.svg.selectAll('.brush').remove();

        switch (this.taskTypes[method]) {
            case 'orientation':
                this.markPanels(30);
                this.render();
                break;
            case 'trends':
                this.markPanels(30);
                this.render();
                break;
            case 'identify':
                this.markPanels(10);
                this.isIdentify = true;
                this.render();
                break;
            case 'quantify':
                this.timePoints = [8, 12, 23]
                this.insertTimePoints([this.timePoints.pop()]);
                this.getUserInput();
                this.render();
                break;
            case 'intervals':
                this.markPanels(30);
                this.render();
                break;
            case 'test':
                this.markPanels(2)
                break;
            default:
                break;
        }
    }

    finishTask() {
        switch (this.taskTypes[this.taskType]) {
            case 'orientation':
                this.submit(this.gatherSelectedPanels());
                break;
            case 'trends':
                this.submit(this.gatherSelectedPanels());
                break;
            case 'quantify':
                if (!Array.isArray(this.estimatePayload)) this.estimatePayload = [];

                const _tmp = this.gatherUserInput();
                if (_tmp) {
                    this.estimatePayload.push(_tmp);
                } else {
                    return;
                }

                if (this.timePoints.length > 0) {
                    this.showNextEstimateModal();
                    this.svg.selectAll('.sm-overlay').classed('selected', false);
                    this.svg.selectAll('text').remove();
                    this.svg.selectAll('.brush').remove();

                    this.insertTimePoints([this.timePoints.pop()]);
                    return
                }
                this.payload = this.estimatePayload;
                this.submit(this.payload);


                break;
            case 'identify':
                if (this.isIdentify) {
                    this.payload = this.gatherSelectedPanels();
                    // deselect all
                    d3.selectAll('.sm-overlay').attr('class', 'sm-overlay');
                    this.showModal(true);
                    this.isIdentify = false;
                    break;
                }
                this.submit(this.payload.concat(this.gatherSelectedPanels()));
                break;
            case 'intervals':
                this.submit(this.gatherSelectedPanels());
                break;
            case 'test':
                const payload = this.gatherSelectedPanels();
                if (payload.length != 2) {
                    alert('Please select exactly 2 panels')
                    return
                }
                //DEBUG
                //alert(`You selected panel ${payload[0]} and panel ${payload[1]}`)
                this.submit()
            default:
                break;
        }
    }

    gatherSelectedPanels() {
        const panels = [];
        d3.selectAll('.selected').each((d, i, g) => panels.push(g[i].dataset.panel));
        return (panels);
    }


    insertTimePoints(panelsToMark) {
        // panels to mark in the form of [1, 3, 5]
        const panels = d3.selectAll('.panel').nodes();
        panelsToMark.forEach((idx, i) => {
            if (idx > panels.length || idx === 0) return;
            const panel = d3.select(panels[idx - 1]);
            const rect = panel.select('.sm-overlay');
            rect.attr('class', 'sm-overlay selected');
            panel.append('text').html(`Estimate here`)
                .attr('x', (+rect.attr('x')) + +rect.attr('width') * 0.2)
                .attr('y', (+rect.attr('y')) + +rect.attr('height') * 0.1)
                .attr('class', 'point-label');
        });
    }

    markPanels(maxPanels, startEnd = false) {
        // Enable click events on panels
        d3.selectAll('.sm-overlay').style('pointer-events', 'all');
        this.maxPanels = maxPanels;
    }


    toggleSelected() {
        const selected = d3.select(d3.event.target);
        if (d3.selectAll('.selected').nodes().length >= this.maxPanels && !selected.classed('selected')) return;
        selected.classed('selected') ? selected.attr('class', 'sm-overlay') : selected.attr('class', 'sm-overlay selected');
    }

    clear() {
        this.containerElement.html(null);
    }

    render() {
        this.width = this.containerElement.node().getBoundingClientRect().width;
        const remainingHeight = window.innerHeight - 0.25 * window.innerHeight
            - document.querySelector(`#task-${this.taskID}-text`).getBoundingClientRect().height
            - document.querySelector('.step-item').getBoundingClientRect().height;
        this.height = remainingHeight;
        this.svg
            .attr('width', '100%')
            .attr('height', this.height);
    }
}
