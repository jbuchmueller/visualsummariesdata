import * as d3 from 'd3';
import { statemanager, baseURL } from '..';

export default class VizEval {


    constructor(containerElement, multiDimensional = false) {
        this.containerElement = d3.select(containerElement);
        this.multiDimensional = multiDimensional;
        this.width = this.containerElement.node().getBoundingClientRect().width;
        this.startTime = Date.now();
        this.taskID = JSON.parse(window.localStorage.getItem('step'));
        this.away = 0;
        this.timesAway = 0;
        this.finishButton = d3.select(`#btn-task-${this.taskID}`).on('click', this.finishTask.bind(this));

    }

    taskTypes = {
        0: 'orientation',
        1: 'trends',
        2: 'identify',
        3: 'quantify',
        4: 'intervals',
        99: 'test'
    }

    clampToBounds(lower, upper, value) {
        return Math.max(lower, Math.min(upper, value));
    }

    clear() {
        this.containerElement.html = '';
    }


    setContainerElement(containerElement) {
        this.containerElement = d3.select(containerElement);
    }


    isNumberInTolerance(actual, expected, tolerance) {
        if (actual - tolerance < expected && actual + tolerance < expected)
            return true
        else
            return false
    }

    toggleAwayListener(remove = false) {
        function handleVisibilityChange() {
            if (document.visibilityState === 'hidden') {
                this.lostFocusAt = Date.now();
                this.timesAway++;
            }
            else {
                this.away += Date.now() - this.lostFocusAt;
            }
        }
        if (remove) {
            document.removeEventListener('visibilitychange', handleVisibilityChange.bind(this));
        }
        else {
            document.addEventListener('visibilitychange', handleVisibilityChange.bind(this));
        }
    }

    setupStart() {
        this.containerElement.style('display', 'none');
        d3.selectAll('.submission').style('display', 'none');
        this.finishButton.style('display', 'none');
        this.startButton = d3.select(this.containerElement.node().parentNode).append('a').classed('button', true).html('Start Task').on('click', this.startTask.bind(this));

    }
    startTask() {
        this.startTime = Date.now();
        this.containerElement.style('display', null);
        this.finishButton.style('display', null);
        this.startButton.style('display', 'none');
        this.render();

        d3.selectAll('.submission').style('display', null);

        // if identify
        if (this.taskType == 2) {
            this.showModal(false);
        }

        this.indexTime = 0;
        try {
            this.resize();
        }
        finally {
            //nothing
        }


    }
    submit(payload, clear = true) {

        this.toggleAwayListener(true);

        const tracking = {
            'start': this.startTime,
            'end': Date.now(),
            'away': this.away,
            'timesAway': this.timesAway,
            'payload': payload
        }



        d3.json(baseURL + 'submit/', {
            method: 'POST', headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': statemanager.storage.get('token')
            }, body: JSON.stringify(tracking)
        })
            .then(
                resp => {
                    statemanager.storage.set('taskType', resp.task_type)
                    statemanager.storage.set('explanation', resp.explanation)
                    statemanager.storage.set('text', resp.text)
                    statemanager.updateTaskText();
                }
            )

        if (clear) this.clear();
        window.removeEventListener('resize', this.render.bind(this));

        try {
            window.removeEventListener('resize', this.resize.bind(this));
        } catch {

        }


        document.querySelector('a[data-nav]').dispatchEvent(new MouseEvent('click'));

        // Find all brushes, get brush coords and push to results array
        // TODO: purge null
        //this.updateBrushCoordindates();
        /*
        if (!this.coordinates) {
            alert('Please select an area.');
        } else {
            alert(`Selected the area between ${2 * Math.round(this.coordinates[0])}
                   and ${2 * Math.round(this.coordinates[1])} in ${(end - this.s1tartTime) / 1000} seconds.`);
        }*/
    }


    gatherUserInput() {
        const userinput = d3.select(`.user-radio:checked`).property('value');
        d3.select('.user-radio:checked').property('checked', false);
        if (!userinput || userinput === '') {
            alert('Please select an Estimate.')
            return false;
        }
        //TODO: validate user input
        return (userinput)
    }


    getUserInput() {
        this.hasUserInput = true;
        const ranges = ['0-19%', '20-39%', '40-59%', '60-79%', '80-100%']


        d3.select(`#submission-task-${this.taskID}`)
            .insert('label', `#submission-task-${this.taskID}>a`)
            .attr('class', 'label has-text-centered')
            .html('Estimate: How many fish are moving fast at the marked point?');

        const checks =
            d3.select(`#submission-task-${this.taskID}`)
                .insert('div', `#submission-task-${this.taskID}>a`)
                .attr('style', "display: flex;justify-content: center;")
                .classed('controls', true)
                .selectAll('input')
                .data(ranges)
                .enter()
                .append('div');


        checks
            .append('input')
            .attr('type', 'radio')
            .attr('id', (d, i) => `user-input-${i}`)
            .attr('value', (d, i) => i)
            .attr('name', 'user-input-range')
            .classed('user-radio', true);

        checks
            .append('label')
            .classed('radio', true)
            .classed('radio-label', true)
            .attr('for', (d, i) => `user-input-${i}`)
            .html(d => d);
    }

    showModal(slow) {
        const modal = d3.select('#fast-slow-modal');
        modal.select('strong').html(slow ? 'fast' : 'slow');
        modal.classed('is-active', true);
    }

    showNextEstimateModal() {
        const modal = d3.select('#next-estimate-modal');
        modal.classed('is-active', true);
    }

}
