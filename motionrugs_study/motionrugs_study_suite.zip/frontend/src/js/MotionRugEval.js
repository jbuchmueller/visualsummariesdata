import * as d3 from 'd3';
import VizEval from './VizEval';

export default class MotionRugEval extends VizEval {
    constructor(containerElement) {
        super(containerElement, false);
    }

    attach(viz) {
        this.clear();

        window.addEventListener('resize', this.render.bind(this));
        this.toggleAwayListener();

        // viz is either a div or the path to an image
        // this.containerElement.html('');
        // We specify the viewbox such thAat the proportions of the motionrug are preserved
        this.undoButton = this.containerElement.append('a')
            .on('click', this.undo.bind(this))
            .text('Undo')
            .classed('button', true)
            .append('i')
            .classed('mdi', true)
            .classed('mdi-undo', true);

        this.undoAllButton = this.containerElement.append('a')
            .on('click', this.undoAll.bind(this))
            .text('Remove all')
            .classed('button', true)
            .append('i')
            .classed('mdi', true)
            .classed('mdi-select-off', true);


        this.pngWidth = viz === "assets/testrug.png" ? 976 : 2700;
        this.pngHeight = 151;

        this.svg = this.containerElement.append('svg')
            .attr('viewBox', `${(this.pngWidth - 2700) / 2} 0 2700 ${this.pngHeight}`)
            .attr('preserveAspectRatio', 'none');

        this.legend = this.containerElement
            .append('img')
            .attr('src', 'assets/legend.png')
            .attr('style', 'margin-left: auto;margin-right: auto;width: 20%;')

        // bind method to class to allow acces to properties further down

        this.svg.append('image').attr('xlink:xlink:href', viz)
            .attr('width', this.pngWidth)
            .attr('height', this.pngHeight);

        this.setupStart();
        this.render();
    }

    changeMethod(method) {
        this.taskType = method;
        this.svg.select('g').remove();
        this.svg.on('click', null);
        switch (this.taskTypes[method]) {
            case 'orientation':
                if (this.lineIndicator) this.lineIndicator.remove();
                this.markTimePoints(40);
                this.render();
                break;
            case 'trends':
                if (this.lineIndicator) this.lineIndicator.remove();
                this.markTimePoints(50);
                this.render();
                break;
            case 'identify':
                if (this.lineIndicator) this.lineIndicator.remove();
                this.isIdentify = true;
                this.markTimePoints(1);
                this.render();
                break;
            case 'quantify':
                if (this.lineIndicator) this.lineIndicator.remove();
                this.timePoints = [837, 1345, 2486];
                this.insertTimePoints(this.timePoints.pop());
                this.getUserInput();
                this.undoAllButton.style('display', 'none');
                this.undoButton.style('display', 'none');
                this.render();
                break;
            case 'intervals':
                if (this.lineIndicator) this.lineIndicator.remove();
                this.markIntervals(10);
                break;
            case 'test':
                if (this.lineIndicator) this.lineIndicator.remove();
                this.markTimePoints(2);
                break;
            default:
                break;
        }
    }

    insertTimePoints(timePointCoords) {
        this.lines = this.svg.append('g');
        const containers = this.lines.selectAll('g').data([timePointCoords]).enter().append('g');
        // Use two separate appends to place as siblings
        containers.append('line').style('stroke', '#FFF').style('stroke-width', '6px')
            .attr('x1', (d) => d)
            .attr('x2', (d) => d)
            .attr('y1', 0)
            .attr('y2', this.pngHeight);
        containers.append('text').html((d, i) => `Estimate at this Point`).attr('x', (d) => d + 10).attr('y', '27%')
            .style('font', 'bold 55px sans-serif')
            .style('fill', '#FFF')
            .style('stroke', '#000');
    }

    markTimePoints(maxPoints) {
        this.maxPoints = maxPoints;
        this.lines = this.svg.append('g');
        this.lineIndicator = this.svg.append('line').style('stroke', '#FFF').style('stroke-width', '5px')
            .attr('y1', 0)
            .attr('y2', this.pngHeight);
        // use closure functions as callbacks to allow proper handling of this and separation of logi

        function mouseMove() {
            const mouse = d3.mouse(this.svg.node());
            this.lineIndicator.attr('x1', mouse[0]).attr('x2', mouse[0] + 1);
        }
        function mouseLeave() {
            this.lineIndicator.attr('x1', -1).attr('x2', -1);
        }
        function mouseClick() {
            const tmpLines = this.lines.selectAll('line');
            if (tmpLines._groups[0].length >= this.maxPoints) {
                tmpLines.each((d, i, node) => {
                    // remove first line to make space for new line
                    d3.select(node[0]).remove();
                });
            }

            const mouse = d3.mouse(this.svg.node());
            this.lines.append('line').style('stroke', '#FFF').style('stroke-width', '5px')
                .attr('x1', mouse[0])
                .attr('x2', mouse[0] + 1)
                .attr('y1', 0)
                .attr('y2', this.pngHeight);
        }

        this.svg.on('mousemove', mouseMove.bind(this));
        this.svg.on('mouseleave', mouseLeave.bind(this));
        this.svg.on('click', mouseClick.bind(this));
    }


    drawBrushes(brushes) {
        const brushSelection = this.brushG
            .selectAll('.brush')
            .data(brushes, (d) => d.id);
        brushSelection.enter()
            .insert('g', '.brush')
            .attr('class', 'brush')
            .attr('id', (brush) => `brush-${brush.id}`)
            .each(function (brushObject) {
                brushObject.brush(d3.select(this));
            });

        brushSelection
            .each(function (brushObject) {
                d3.select(this)
                    .attr('class', 'brush')
                    .selectAll('.overlay')
                    .style('pointer-events', () => {
                        const { brush } = brushObject;
                        if (brushObject.id === brushes.length - 1 && brush !== undefined) {
                            return 'all';
                        }
                        return 'none';
                    });
            });

        brushSelection.exit()
            .remove();
    }

    markIntervals(maxIntervals) {
        this.coordinates = [];
        if (maxIntervals === 1) {
            this.markInterval();
            return;
        }

        const brushes = [];
        this.brushG = this.svg.append('g').attr('class', 'brushes');
        function newBrush(that) {
            const brush = that.multiDimensional ? d3.brush() : d3.brushX();
            brush.on('end', brushends.bind(that));
            // save brush id in prototype, feels hacky but less so than other apporaches I tried
            brush.brushID = `brush-${brushes.length}`;
            brushes.push({ id: brushes.length, brush });
            that.brushes = brushes;
        }

        function brushends() {
            const movedBrushID = parseInt(d3.event.target.brushID.charAt(d3.event.target.brushID.length - 1));
            const lastBrushID = brushes[brushes.length - 1].id;

            const lastBrush = document.getElementById(`brush-${lastBrushID}`);
            const preSelection = d3.brushSelection(lastBrush);
            if (preSelection && preSelection[0] !== preSelection[1]) newBrush(this);
            this.drawBrushes(this.brushes);

            const { selection } = d3.event;
            this.updateBrushCoordindates();
            const collider = this.brushCollides(selection);
            let collides = false;
            collider[0] === -1 || collider[1] === -1 ? collides = false : collides = true;
            if (collides) {
                if (!this.multiDimensional) this.brushes[movedBrushID].brush.move(d3.select(`#brush-${movedBrushID}`), collider);
                else {
                    // this.brushes[movedBrushID].brush.move(d3.select(`#brush-${movedBrushID}`), null);
                    delete this.brushes[movedBrushID];
                    d3.select(`#brush-${movedBrushID}`).remove();
                }
                this.updateBrushCoordindates();
            }
            this.drawBrushes(this.brushes);
        }


        newBrush(this);
        this.drawBrushes(brushes);
    }

    brushCollides(brushSelection) {
        if (this.coordinates.length === 0 || !brushSelection) return [-1, -1];
        let fixedCoords = [-1, -1];
        if (!this.multiDimensional) {
            this.coordinates.forEach((d) => {
                if (d && d[0] === brushSelection[0] && d[1] === brushSelection[1]) return;
                // Colliders are cut off to avoid infinite looping
                // Collider to the left?
                const width = d[1] - d[0];
                if (d[0] <= brushSelection[0] && brushSelection[0] <= d[1]) fixedCoords = [d[1] + 1, brushSelection[1]];
                // Collider to the right?
                if (d[0] <= brushSelection[1] && brushSelection[1] <= d[1]) fixedCoords = [brushSelection[0], d[0] - 1];
                // Collider 1 included in 2
                if (brushSelection[0] < d[0] && brushSelection[1] > d[1]) fixedCoords = [d[1], brushSelection[1] + width];
                // Colliders 2 included in 1
                if (brushSelection[0] > d[0] && brushSelection[1] < d[1]) fixedCoords = [d[1], brushSelection[1] + width];
            });
        } else {
            this.coordinates.forEach((d) => {
                if (d && d[0][0] === brushSelection[0][0] && d[0][1]
                    === brushSelection[0][1] && d[1][0] === brushSelection[1][0]
                    && d[1][1] === brushSelection[1][1]) return;
                const width1 = d[1][0] - d[0][0];
                const width2 = brushSelection[1][0] - brushSelection[0][0];
                const height1 = d[1][1] - d[0][1];
                const height2 = brushSelection[1][1] - brushSelection[0][1];

                if (d[0][0] < brushSelection[0][0] + width2
                    && d[0][0] + width1 > brushSelection[0][0]
                    && d[0][1] < brushSelection[0][1] + height2
                    && d[0][1] + height1 > brushSelection[0][1]) fixedCoords = [[d[0][0], d[1][1]], [brushSelection[0][0], brushSelection[1][1]]];
            });
        }
        return fixedCoords;
    }

    markInterval() {
        const brush = this.multiDimensional ? d3.brush() : d3.brushX();
        this.svg.append('g').attr('class', 'brush').call(brush.handleSize(25)
            .on('end', brushed.bind(this)));
        function brushed() {
            const { selection } = d3.event;
            this.coordinates = selection;
        }
    }

    finishTask() {
        switch (this.taskTypes[this.taskType]) {
            //TODO: payload system & validation here?
            case 'orientation':
                this.submit(this.gatherLines());
                break;
            case 'trends':
                this.submit(this.gatherLines());
                break;
            case 'identify':
                if (this.isIdentify) {
                    this.payload = this.gatherLines();
                    this.lines.selectAll('line').remove();
                    //alert('Please select the slowest movers now.');
                    this.showModal(true);
                    this.isIdentify = false;
                    break;
                }
                this.submit(this.payload.concat(this.gatherLines()));
                break;
            case 'quantify':
                if (!Array.isArray(this.estimatePayload)) this.estimatePayload = [];

                const _tmp = this.gatherUserInput();
                if (_tmp) {
                    this.estimatePayload.push(_tmp);
                } else {
                    return;
                }

                if (this.timePoints.length > 0) {
                    this.showNextEstimateModal();
                    this.lines.remove();
                    this.insertTimePoints(this.timePoints.pop());
                    return
                }
                this.payload = this.estimatePayload;
                this.submit(this.payload);

                break;
            case 'intervals':
                this.submit(this.gather1dBrushes());
                break;
            case 'test':
                const payload = this.gatherLines();
                if (payload.length != 2) {
                    alert('Please mark exactly two points in time.')
                    return
                }

                if (payload[0] >= 119 && payload[0] <= 237) {
                    alert('Point 1 correct.')
                } else {
                    alert('Point 1 incorrect')
                    return;
                }

                if (payload[1] >= 609 && payload[1] <= 697) {
                    alert('Point 2 correct.')
                } else {
                    alert('Point 2 incorrect')
                    return;
                }
                this.submit('none');
                break;
            default:
                break;
        }
    }

    gatherLines() {
        const coords = [];
        this.lines.selectAll('line').each((d, i, g) => coords.push(d3.select(g[i]).attr('x1')));
        return (coords);
    }

    gather1dBrushes() {
        this.updateBrushCoordindates();
        return (this.coordinates);
    }


    updateBrushCoordindates() {
        d3.selectAll('g.brush').each((d, i, node) => {
            const sel = d3.brushSelection(d3.select(node[i]).node());
            if (sel !== null) this.coordinates[d.id] = sel;
        });
    }

    render() {
        this.width = this.containerElement.node().getBoundingClientRect().width;
        this.svg
            .attr('width', this.width)
            .attr('height', this.width / 18);
    }

    undo() {
        if (this.lines) {
            const tmplines = this.lines.selectAll('line')._groups[0];
            if (tmplines.length > 0) d3.select(tmplines[tmplines.length - 1]).remove();
        }
        if (this.brushes && this.brushes.length > 2) {
            const lastBrushID = this.brushes[this.brushes.length - 2].id;
            d3.select(`#brush-${lastBrushID}`).remove();
            d3.select(`#brush-${lastBrushID + 1}`).remove();
            this.brushes.splice(this.brushes.length - 2, 2);
            this.drawBrushes(this.brushes);
        }
    }

    undoAll() {
        if (this.lines) {
            this.lines.selectAll('line').remove();
        }
        if (this.brushes) {
            d3.selectAll('g.brush').remove();
            d3.select('g.brushes').remove();
            this.brushes = [];
            this.markIntervals();
        }
    }

}
