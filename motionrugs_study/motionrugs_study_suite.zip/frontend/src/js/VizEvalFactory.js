import AnimationEval from "./AnimationEval";
import MotionRugEval from "./MotionRugEval";
import SmallMultiplesEval from "./SmallMultiplesEval";


export default class VizEvalFactory {

    constructor(vizType, containerElement) {
        switch(parseInt(vizType)) {
            case 0:
                return null;
                break;
            case 1: 
                return new AnimationEval(containerElement);
                break;
            case 2:
                return new MotionRugEval(containerElement);
                break;
            case 3:
                return new SmallMultiplesEval(containerElement);
                break;
            case 4:
                return new SmallMultiplesEval(containerElement);
                break;
            default:
                return null;
        }
    }

    vizTypes = [
        'TestTask',
        'Animation',
        'MotionRug',
        'Small Multiples',
        'Streamlines'
    ]
}