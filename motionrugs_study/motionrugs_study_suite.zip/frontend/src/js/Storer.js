
export default class Storer {
    constructor() {
        if (this.hasSession()) {
            this.restoreSession();
        } else {
            this.set('keys', []);
            this.set('step', 0);
        }
    }

    get(key) {
        return JSON.parse(window.localStorage.getItem(key));
    }

    set(key, value) {
        window.localStorage.setItem(key, JSON.stringify(value));
        const keys = JSON.parse(window.localStorage.getItem('keys'));
        keys.push(key);
        window.localStorage.setItem('keys', JSON.stringify(keys));
    }

    hasSession() {
        if (this.get('hasSession')) return true;
        return false;
    }

    restoreSession() {
        console.log('Has Session.');
        return false;
    }
}
