
export default class TaskTracking {
    constructor(taskId, groupId, startTime, type) {
        this.taskId = taskId;
        this.groupId = groupId;
        this.startTime = startTime;
        this.referer = this.getReferer();
        this.type = type;
    }

    getReferer() {
        if (window.location.pathname === '/') return 'hallo';
        // TODO: handle using modal?

        const referer = window.location.pathname.split('/')[1];
        return referer;
    }
}
