import * as d3 from 'd3';
import { sliderHorizontal, sliderTop } from 'd3-simple-slider';
import { baseURL, statemanager } from '..';
import VizEval from './VizEval';

export default class AnimationEval extends VizEval {
    constructor(containerElement) {
        super(containerElement, false);
        this.parameters = {
            // this is hardcoded for the golden shiner dataset
            min: [41.56, 30.31],
            max: [1783.24, 1053.98],
            fps: 25,
            inverted_x: -1,
            inverted_y: 1,
        };
        this.indexTime = 0;
        this.activeAnimals = [];
        this.dataset = [];
        this.playBoolean = true;
        d3.selection.prototype.hide = function () {
            this.style('display', 'none');
            return this;
        };
        d3.selection.prototype.show = function () {
            this.style('display', 'initial');
            return this;
        };

    }


    attach(from) {
        this.containerElement.html(this.controlPanel);

        this.indexMax = from.includes('test') ? 76 : 108;
        this.scale = d3.scaleLinear([60, 960], [0, this.indexMax]).clamp(true);

        this.setupStart();

        if (!statemanager.hasData(from)) {
            //TODO: Reset sliders on method change?
            this.initSliders()
            this.streamMovementData(from);
        } else {
            this.from = from;
            this.initSliders();
            this._attach();
        }
    }

    _attach() {

        // calculate parameters


        const minPoint = this.parameters.min;
        const maxPoint = this.parameters.max;
        let tankWidth;
        let tankHeight;
        // width = width *1.02 --> so there is a margin in the spatial view where no animal is ever
        tankWidth = (maxPoint[0] - minPoint[0]) * 1.02;
        tankHeight = (maxPoint[1] - minPoint[1]) * 1.02;
        this.tankHeight = tankHeight;
        this.tankWidth = tankWidth;
        // X and Y axis
        const x = d3.scaleLinear()
            .domain([minPoint[0], maxPoint[0]])
            .range([minPoint[0], maxPoint[0]]);

        const xAxis = d3.axisBottom(x)
            .ticks(10)
            .tickSize(10)
            .tickPadding(5);

        const y = d3.scaleLinear()
            .domain([minPoint[1], maxPoint[1]])
            .range([minPoint[1], maxPoint[1]]);

        const yAxis = d3.axisRight(y)
            .ticks(7)
            .tickSize(10)
            .tickPadding(5);

        const svgContainer = this.containerElement.select('#main-vis')
            .classed('svg-container', true)
            // to make it responsive with css
            .append('svg')
            .attr('preserveAspectRatio', 'xMinYMin meet')
            .attr('viewBox', `0 0 ${tankWidth} ${tankHeight}`)
            // add the class svg-content
            .classed('svg-content', true)
            .attr('id', 'main-vis-svg');

        this.svgContainer = svgContainer;

        this.resize();
        window.addEventListener('resize', this.resize.bind(this));

        /* depends on svg ratio, for e.g 1240/1900 = 0.65 so padding-bottom = 65% */
        //const percentage = Math.ceil((tankHeight / tankWidth) * 100);
        //this.containerElement.select('#main-vis').append('style').html(`#main-vis::after {padding-top: ${percentage}%;display: block;content: "";}`);


        // append the tank group with a transformation which rotates the y axis
        this.tank = this.svgContainer.append('svg:g')
            .attr('class', 'tank')
            .attr('transform', 'scale(1, -1)');


        // append the frame time text
        svgContainer.append('text')
            .attr('class', 'frame-text')
            .attr('x', 30)
            .attr('y', 30)
            .style('font', 'bold 25px sans-serif')
            .text('- : -- : -- ');

        // add the axes
        svgContainer.append('g')
            .attr('class', 'x axis')
            .call(xAxis);

        svgContainer.append('g')
            .attr('class', 'y axis')
            .call(yAxis);

        // append legend

        this.scaleLegend = d3.scaleLinear([550, 780], [1800, 1300]).clamp(true);
        const legendTransform = this.scaleLegend(this.height);
        svgContainer.append('g')
            .attr('id', 'legend')
            .attr('transform', 'translate(' + legendTransform + ',0)')
            .append('image')
            .attr('xlink:xlink:href', 'assets/legend.png')
            .attr('width', '500');


        //this.initSliders();
        this.initListeners();

        // remove loading stuff
        this.containerElement.select('#loading').remove();
        this.containerElement.select('#play-button').classed('is-loading', false);

        // start the animation
        this.render();
    }

    changeMethod(method) {
        this.taskType = method;
        switch (this.taskTypes[method]) {
            case 'orientation':
                this.markTimePoints(50);
                this.toggleSliderRange('off');
                break;
            case 'trends':
                this.markTimePoints(50);
                this.toggleSliderRange('off');
                break;
            case 'identify':
                // set var to quey multiple times
                this.isIdentify = true;
                this.markTimePoints(1);
                this.toggleSliderRange('off');
                break;
            case 'quantify':
                this.getUserInput();
                this.timePoints = [22, 40, 57];
                this.insertTimePoints(this.timePoints.pop());
                this.toggleSliderRange('off')
                break;
            case 'intervals':
                this.markIntervals(50);
                this.toggleSliderRange('off');
                break;
            case 'test':
                this.markTimePoints(2);
                this.toggleSliderRange('off');
                break;
            default:
                break;
        }
    }

    insertTimePoints(atTime) {
        // Mark timepoints on the input slider
        this.svg = d3.select(this.containerElement.select('g#inputslider').node().parentNode);
        this.lines = this.svg.append('g').attr('class', 'timepoint-line');
        const g = this.lines;
        const time = this.scale.invert(atTime);
        g.append('line').style('stroke', '#000').style('stroke-width', '3px')
            .attr('x1', time)
            .attr('x2', time + 1)
            .attr('y1', 0)
            .attr('y2', 100);
        g.append('text')
            .attr('x', time + 2)
            .attr('y', 28)
            .style('font', '13px sans-serif')
            .style('fill', '#000')
            .style('stroke', '#000')
            .html(`Estimate at this point.`);
    }

    markIntervals(maxIntervals) {
        this.maxIntervals = maxIntervals;
        this.svg = d3.select(this.containerElement.select('g#inputslider').node().parentNode);
        this.lines = this.svg.append('g').attr('class', 'timepoint-line');
        this.startLine = this.lines.append('line').style('stroke', '#008000').style('stroke-width', '3px')
            .attr('y1', 0)
            .attr('y2', 100)
            .attr('id', 'start-line');
        this.endLine = this.lines.append('line').style('stroke', '#8B0000').style('stroke-width', '3px')
            .attr('y1', 0)
            .attr('y2', 100)
            .attr('id', 'end-line');
        // use closure functions as callbacks to allow proper handling of this and separation of logi

        this.isStart = true;

        function mouseMove() {
            const mouse = d3.mouse(this.svg.node());
            if (this.isStart) {
                this.startLine.attr('x1', mouse[0]).attr('x2', mouse[0]);
            } else {
                this.endLine.attr('x1', mouse[0]).attr('x2', mouse[0]);
            }
        }
        function mouseLeave() {
            //this.lineIndicator.attr('x1', -1).attr('x2', -1);
        }

        function mouseClick() {
            this.containerElement.select('#remove-active-selected-button').property('disabled', false)
            const tmpLines = this.lines.selectAll('.marker');
            // Need 2 points per interval
            if (tmpLines._groups[0].length / 2 >= this.maxIntervals) {
                tmpLines.each((d, i, node) => {
                    // remove first interval to make space for new line
                    d3.select(node[0]).remove();
                    d3.select(node[1]).remove();

                });

            }

            const mouse = d3.mouse(this.svg.node());

            if (this.isStart) {
                this.g = this.lines.append('g').attr('class', 'marker');
                this.startX = mouse[0];
            } else {
                if (mouse[0] <= this.startX) {
                    alert('End can not be before start')
                    return
                } else {
                    this.g.append('rect').attr('x', this.startX + 1).attr('y', 0).attr('height', 100).attr('width', mouse[0] - this.startX)
                        .attr('fill', 'hsl(171, 100%, 41%)').attr('fill-opacity', 0.25)
                }
            }


            this.g.append('line').style('stroke', this.isStart ? '#008000' : '#8B0000').style('stroke-width', '3px')
                .attr('x1', mouse[0])
                .attr('x2', mouse[0])
                .attr('y1', 0)
                .attr('y2', 100);
            this.g.append('text')
                .attr('x', mouse[0] + 2)
                .attr('y', 30)
                .style('font', 'bold 13px sans-serif')
                .style('fill', '#000')
                .style('stroke', '#000')
                .html(`${this.isStart ? 'Start:' : 'End: '} ${Math.round(this.scale(Math.round(mouse[0])))}s`);

            this.isStart = !this.isStart

        }

        this.svg.on('mousemove', mouseMove.bind(this));
        this.svg.on('mouseleave', mouseLeave.bind(this));
        this.svg.on('click', mouseClick.bind(this));
    }

    markTimePoints(maxPoints) {
        this.maxPoints = maxPoints;
        this.svg = d3.select(this.containerElement.select('g#inputslider').node().parentNode);
        this.lines = this.svg.append('g').attr('class', 'timepoint-line');
        this.lineIndicator = this.lines.append('line').style('stroke', '#000').style('stroke-width', '3px')
            .attr('y1', 0)
            .attr('y2', 100)
            .attr('id', 'helper-line');
        // use closure functions as callbacks to allow proper handling of this and separation of logi

        function mouseMove() {
            const mouse = d3.mouse(this.svg.node());
            this.lineIndicator.attr('x1', mouse[0]).attr('x2', mouse[0] + 1);
        }
        function mouseLeave() {
            //this.lineIndicator.attr('x1', -1).attr('x2', -1);
        }
        function mouseClick() {
            this.containerElement.select('#remove-active-selected-button').property('disabled', false)
            const tmpLines = this.lines.selectAll('.marker');
            if (tmpLines._groups[0].length >= this.maxPoints) {
                tmpLines.each((d, i, node) => {
                    // remove first line to make space for new line
                    d3.select(node[0]).remove();
                });
            }

            const mouse = d3.mouse(this.svg.node());


            const g = this.lines.append('g').attr('class', 'marker');

            const clamped = this.clampToBounds(60, 960, mouse[0]);
            g.append('line').style('stroke', '#000').style('stroke-width', '3px')
                .attr('x1', clamped)
                .attr('x2', clamped + 1)
                .attr('y1', 0)
                .attr('y2', 100);
            g.append('text')
                .attr('x', clamped + 2)
                .attr('y', 30)
                .style('font', 'bold 13px sans-serif')
                .style('fill', '#000')
                .style('stroke', '#000')
                .html(` ${Math.round(this.scale(Math.round(clamped)))}s`);
        }

        this.svg.on('mousemove', mouseMove.bind(this));
        this.svg.on('mouseleave', mouseLeave.bind(this));
        this.svg.on('click', mouseClick.bind(this));
    }

    gatherLines() {
        const coords = [];
        this.lines.selectAll('line').each((d, i, g) => coords.push(d3.select(g[i]).attr('x1')));
        return (coords);
    }

    gatherIntervals() {
        const coords = [];
        this.lines.selectAll('rect').each((d, i, g) => {
            const node = d3.select(g[i]);
            coords.push([this.scale(Number(node.attr('x'))), this.scale(Number(node.attr('x')) + Number(node.attr('width')))])
        })
        return (coords)
    }

    initSliders() {
        this.slider = sliderHorizontal()
            .min(0)
            .max(this.indexMax)
            .ticks(this.indexMax / 3)
            .width(900)
            .on('onchange', (value) => {
                this.indexTime = Math.round(value * 25);
                if (!this.playBoolean) this.render();
            })
            .on('end', (value) => this.indexTime = Math.round(value * 25));


        const timeSlider =
            this.containerElement.select('#slider')
                .append('svg')
                .attr('viewBox', '0 0 1000 70');

        timeSlider
            .append('text')
            .attr('x', 5)
            .attr('y', 30)
            .text('Time');
        timeSlider
            .append('g')
            .attr('transform', 'translate(60, 25)')
            .attr('id', 'time-slider')
            .style('display', 'block')
            .call(this.slider);

        this.sliderRange = sliderTop()
            .min(0)
            .max(this.indexMax)
            .ticks(this.indexMax / 3)
            .fill('hsl(171, 100%, 41%)')
            .width(900);


        const inputslider = this.containerElement.select('#slider')
            .append('svg')
            .attr('viewBox', '0 0 1000 30');

        inputslider
            .append('text')
            .attr('x', 5)
            .attr('y', 20)
            .text('Input');
        inputslider
            .append('g')
            .attr('transform', 'translate(60, 15)')
            .attr('id', 'inputslider')
            .style('display', 'block')
            .call(this.sliderRange);
    }

    toggleSliderRange(toggle) {
        const handles = this.containerElement.selectAll('g#inputslider>g.slider>g.parameter-value');
        const fill = this.containerElement.select('g#inputslider>g.slider>line.track-fill')
        if (toggle === 'on') {
            handles.nodes().forEach((n) => n.style.display = '');
            fill.show();
            return
        }
        else {
            handles.nodes().forEach((n) => n.style.display = 'none');
            fill.hide();
            return
        }
    }

    initListeners() {
        /**
         * Play or stop the animation
         */
        this.containerElement.select('#play-button').on('click', () => {
            if (this.containerElement.select('#play-button').classed('is-active')) {
                this.playBoolean = false;
                this.containerElement.select('#play-pause').classed('mdi-pause', false)
                    .classed('mdi-play', true);
                this.containerElement.select('#play-button').classed('is-active', false);
            } else {
                this.playBoolean = true;

                this.containerElement.select('#play-pause').classed('mdi-pause', true)
                    .classed('mdi-play', false);
                this.containerElement.select('#play-button').classed('is-active', true);

                this.render();
            }
        });

        this.containerElement.select(`#fast-button-${this.taskID}`).on('click', () => {
            if (this.containerElement.select(`#fast-button-${this.taskID}`).classed('is-active')) {
                this.containerElement.select('#normal-fast').classed('mdi-skip-forward-outline', false)
                    .classed('mdi-play-outline', true);
                this.containerElement.select(`#fast-button-${this.taskID}`).classed('is-active', false).property('value', 1);
            } else {

                this.containerElement.select('#normal-fast').classed('mdi-skip-forward-outline', true)
                    .classed('mdi-play-outline', false);
                this.containerElement.select(`#fast-button-${this.taskID}`).classed('is-active', true).property('value', 25);
            }
        });



        /**
         * Unselect all button
         */
        this.containerElement.select('#remove-active-selected-button').on('click', () => {
            if (!this.containerElement.select('#remove-active-selected-button').property('disabled')) {
                this.containerElement.select('#remove-active-selected-button').property('disabled', true);
                this.lines.selectAll('.marker').remove();
                // Reset start toggle for intervals
                this.isStart = true;
                if (!this.containerElement.select('#play-button').classed('is-active')) {
                    // go back one second and draw the next frame
                    // this applys the changes
                    this.indexTime--;
                    this.render();
                }
            }
        });

        /**
         * Undo button
         */
        this.containerElement.select('#undo-button').on('click', () => {
            const markers = this.lines.selectAll('.marker');
            markers._groups[0][markers._groups[0].length - 1].remove();
            this.isStart = true;
        })


        /**
         * Finish task
         */
    }

    finishTask() {

        let payload = '';

        switch (this.taskTypes[this.taskType]) {
            case 'orientation':
                payload = this.gatherLines();
                break;
            case 'trends':
                payload = this.gatherLines();
                break;
            case 'identify':
                if (this.isIdentify) {
                    //this.fastest = this.gatherIntervals();
                    this.fastest = this.gatherLines();
                    // reset, break and issue notification to user for second gathering
                    this.isIdentify = false;
                    this.containerElement.selectAll('.marker').remove();
                    this.showModal(true);
                    return
                } else {
                    payload = { fastest: this.fastest, slowest: this.gatherLines() };
                }
                break;
            case 'quantify':
                if (!Array.isArray(this.estimatePayload)) this.estimatePayload = [];

                const _tmp = this.gatherUserInput();
                if (_tmp) {
                    this.estimatePayload.push(_tmp);
                } else {
                    return;
                }

                if (this.timePoints.length > 0) {
                    this.showNextEstimateModal();
                    this.lines.remove();
                    this.insertTimePoints(this.timePoints.pop());
                    return
                }
                payload = this.estimatePayload;
                break;
            case 'intervals':
                payload = this.gatherIntervals();
                break;
            case 'test':
                // screen coords to seconds
                payload = this.gatherLines().map(x => this.scale(+x));
                payload.sort();

                // Test is successful if: 
                // Two intervals
                // #1 : 22-30
                // #2 : 50-60
                if (payload.length != 2) {
                    alert('Please mark exactly two intervals.')
                    return
                }

                if (22 <= payload[0] && payload[0] <= 30) {
                } else {
                    alert('Moment 1 incorrect')
                    return
                }

                if (50 <= payload[1] && payload[1] <= 60) {
                } else {
                    alert('Moment 2 incorrect')
                    return
                }

                break;
            default:
                break;
        }



        if (payload && (payload.length > 0 || Object.keys(payload).length > 1)) {
            this.svgContainer.remove();
            this.containerElement.remove();
            this.submit(payload);
            window.clearTimeout(this.timeOut);
        } else {
            alert('Please make a valid selection')
        }
    }

    gatherLines() {
        const coords = [];
        this.containerElement.selectAll('.marker>line').each((d, i, g) => coords.push(d3.select(g[i]).attr('x1')))
        return (coords)
    }

    setIndexTime() {
        if (typeof value === 'number' && (this.indexTime <= swarmData.length)) {
            this.indexTime = value;
        } else {
            this.indexTime = 0;
        }
    }

    brushend() {
        d3.select('#remove-active-selected-button').property('disabled', false);
        const { arrayAnimals } = this;
        const { activeAnimals } = this;
        const rect = d3.event.selection;

        if (!d3.select('#play-button')
            .classed('is-active')) {
            // go back one second and draw the next frame
            // this applys the changes
            this.indexTime--;
            this.render();
        }
    }

    render() {
        const { tank } = this;

        // update time to wait aka speed of replay
        const timeToWait = d3.select(`#fast-button-${this.taskID}`)
            .property('value');
        // scale the size by this number
        const animalScale = 6;
        // get the next animals
        const arrayAnimals = statemanager.dataset[this.from].filter((d) => (+d.t) === this.indexTime);
        // the timeout is set after one update 30 ms
        this.timeOut = setTimeout(() => {
            // change the time frame text
            this.svgContainer.select('.frame-text')
                .text(`${Math.floor(this.indexTime / 1900) % 60}:${Math.floor(this.indexTime / this.parameters.fps) % 60}::${this.indexTime % this.parameters.fps}`);
            // if a second has changed move the slider
            if (this.indexTime % this.parameters.fps === 0) {
                this.slider.value(this.indexTime / 25);
            }
            const svgAnimals = tank.selectAll('g.animal')
                .data(arrayAnimals);

            // ENTER - append the animal groups
            const animalGroupings = svgAnimals
                .enter()
                .append('g')
                .attr('class', 'animal')
                .attr('id', (d) => `animal-${d.a}`);
            // Append the circles for each animal to the animalgroup
            animalGroupings.append('circle')
                .attr('r', animalScale)
                .attr('cx', (d) => +d.x)
                .attr('cy', (d) => -d.y);

            // UPDATE - animals circles
            svgAnimals.select('circle')
                .attr('cx', (d) => +d.x)
                .attr('cy', (d) => -d.y)
                .attr('r', animalScale)
                .attr('class', (d) => `fish-color-${d.s}`);

            // EXIT - the groups
            svgAnimals.exit()
                .remove();


            // next frame
            this.indexTime++;
            // check if play button is active and if the animation is not finished
            if (this.indexTime >= this.indexMax * 25) {
                // start again from the start
                this.indexTime = 0;
                this.render();
            } else if (this.playBoolean) {
                this.render();
            }
        }, timeToWait);
    }

    streamMovementData(from) {
        this.progress = 0;
        this.from = from;
        if (!statemanager.dataset[from])
            statemanager.dataset[from] = [];
        if (window.EventSource) {
            const source = new EventSource(`${baseURL}/${from}`);
            source.onmessage = function (e) {
                if (e.data === 'close') {
                    source.close();
                    this._attach();
                } else {
                    statemanager.dataset[from] = statemanager.dataset[from].concat(JSON.parse(e.data));
                    //this.dataset = this.dataset.concat(JSON.parse(e.data));
                    this.progress++;
                    if (this.progress % 2 == 0) d3.select('#progress').html(`${this.progress}%`);
                }
            }.bind(this);

            source.addEventListener('error', (e) => {
                if (e.readyState == EventSource.CLOSED) {
                    alert('Streaming error');
                }
            }, false);
        } else {
            alert('Webbrowser does not support streaming');
        }
    }

    resize() {
        this.width = this.containerElement.node().getBoundingClientRect().width;
        const remainingHeight = window.innerHeight - 0.3 * window.innerHeight
            - document.querySelector('.step-item').getBoundingClientRect().height -
            - document.querySelector(`#task-${this.taskID}-text`).getBoundingClientRect().height
            - document.querySelector('.card-body').getBoundingClientRect().height
            - document.querySelector('footer').getBoundingClientRect().height;
        this.height = remainingHeight;
        this.svgContainer
            .attr('width', this.width)
            .attr('height', this.height);
        if (this.scaleLegend) {
            const legendTransform = this.scaleLegend(this.height);
            this.containerElement.select('#legend').attr('transform', 'translate(' + legendTransform + ',0)')
        }
    }

    // JSX sits somewhere in a corner, crying
    controlPanel = `<div class="columns is-centered">
    <div class="column is-12">
        <div class="column is-12">
            <div class="card bg-light">
                <div class="card-body">
                    <div class="button-group" style="padding-right:7px;padding-left:7px;">
                        <div id="animation-buttons" class="buttons has-addons no-bottom-margin">

                            <!-- Play button  -->
                            <button type="button" id="play-button" class="button is-loading is-active is-primary"
                                data-toggle="button" aria-pressed="true" autocomplete="off" data-toggle="tooltip"
                                data-placement="top" title="Play/Pause">
                                <span class="icon" id="play-icons">
                                    <i id="play-pause" class="mdi mdi-pause"></i>
                                </span>
                            </button>


                            <button type="button" id="fast-button-${this.taskID}" class="button is-active"
                                data-toggle="button" aria-pressed="true" autocomplete="off" data-toggle="tooltip"
                                data-placement="top" title="Normal/Fast Speed" value="25">
                                <span class="icon" id="speed-icons">
                                    <i id="normal-fast" class="mdi mdi-skip-forward-outline"></i>
                                </span>
                            </button>

                        </div>

                        <div id="annotate-buttons" class="buttons has-addons no-bottom-margin">
                            <button type="button" id="undo-button" class="button btn-secondary"
                            data-toggle="button" autocomplete="off" data-toggle="tooltip"
                            data-placement="top" title="Deselect all">
                            <i class="mdi mdi-undo"></i>
                        </button>
                            <button type="button" id="remove-active-selected-button" class="button btn-secondary"
                                data-toggle="button" autocomplete="off" data-toggle="tooltip"
                                data-placement="top" title="Deselect all">
                                <i class="mdi mdi-selection-off"></i>
                            </button>
                        </div>
                    </div>

                    <!-- The time slider -->
                    <div class="columns" >
                        <div class="column">
                            <div id="slider"></div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="column" style="text-align: center;">
            <div id="main-vis-div">
                <!-- loading gif -->
                <div id="loading">
                    <i class="mdi mdi-48px mdi-spin mdi-loading"></i>
                    <h4 id="progress">0%</h4>
                </div>
                <!-- The div for the svg  -->
                <div id="main-vis">
                </div>
            </div>

        </div>
    </div>
</div>`

}
