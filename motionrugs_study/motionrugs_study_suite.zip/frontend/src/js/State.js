import * as d3 from 'd3';
import Storer from './Storer';
import { baseURL } from '..';
import VizEvalFactory from './VizEvalFactory';

export default class State {
    dataset = {}
    payloads = [
        [''],
        [''],
        'assets/motionrug.png',
        ['assets/test_multiples_1.png',
            'assets/test_multiples_2.png',
            'assets/test_multiples_3.png',
            'assets/test_multiples_4.png',
            'assets/test_multiples_5.png',
            'assets/test_multiples_6.png',
            'assets/test_multiples_7.png',
            'assets/test_multiples_8.png',
            'assets/test_multiples_8.png',
            'assets/test_multiples_10.png',
            'assets/test_multiples_11.png',
            'assets/test_multiples_12.png',
            'assets/test_multiples_13.png',
            'assets/test_multiples_14.png',
            'assets/test_multiples_15.png',
            'assets/test_multiples_16.png',
            'assets/test_multiples_17.png',
            'assets/test_multiples_18.png',
            'assets/test_multiples_19.png',
            'assets/test_multiples_20.png',
            'assets/test_multiples_21.png',
            'assets/test_multiples_22.png',
            'assets/test_multiples_23.png',
            'assets/test_multiples_24.png'],
        ['assets/test_streamline_1.png',
            'assets/test_streamline_2.png',
            'assets/test_streamline_3.png',
            'assets/test_streamline_4.png',
            'assets/test_streamline_5.png',
            'assets/test_streamline_6.png',
            'assets/test_streamline_7.png',
            'assets/test_streamline_8.png',
            'assets/test_streamline_8.png',
            'assets/test_streamline_10.png',
            'assets/test_streamline_11.png',
            'assets/test_streamline_12.png',
            'assets/test_streamline_13.png',
            'assets/test_streamline_14.png',
            'assets/test_streamline_15.png',
            'assets/test_streamline_16.png',
            'assets/test_streamline_17.png',
            'assets/test_streamline_18.png',
            'assets/test_streamline_19.png',
            'assets/test_streamline_20.png',
            'assets/test_streamline_21.png',
            'assets/test_streamline_22.png',
            'assets/test_streamline_23.png',
            'assets/test_streamline_24.png']
    ]


    explanation = [
        ['Animexpl-1.webm', 'anleitunganimation.png'],
        'anleitungmotionrugs.png',
        'smallmultiples.png',
        'streamexpl.png',
    ]

    constructor() {
        this.storage = new Storer();
        this.step = 0;
        this.currentState = 'signup'
    }

    next() {

        if (this.getStep() >= 5) {
            d3.select('#final-step').html('<strong>Thanks for participating!</strong>')
        }

        switch (this.currentState) {
            case 'signup':
                if (this.signup() !== 0)
                    return 'Form not valid'
                this.payloads[1] = 'test_data';
                this.payloads[2] = 'assets/testrug.png';
                return 0
                break;
            case 'firstTask':
                this.storage.set('step', this.storage.get('step') + 1);
                this.payloads[1] = 'movement_data'
                this.payloads[2] = 'assets/motionrug.png'
                this.payloads[3] = this.payloads[3].map(d => d.replace('test', 'eval'));
                this.payloads[4] = this.payloads[4].map(d => d.replace('test', 'eval'));
                return 0
                break;
            case 'taskState':
                this.storage.set('step', this.storage.get('step') + 1);
                return 0
                break;
            case 'finalPage':

        }

    }

    updateTaskText() {
        const exp = d3.select(`#explanation-${this.storage.get('step')}`).insert('p', 'a').html(this.storage.get('explanation'));
        const figure = d3.select(`#explanation-${this.storage.get('step')}`).insert('p', 'a').append('figure');


        switch (this.storage.get('group')) {
            case 1:
                figure.attr('style', 'margin-left: auto;margin-right: auto;width: 50%;display: block;');
                exp.insert('img', ':first-child')
                    .attr('height', 'auto')
                    .attr('style', 'margin-left: auto;margin-right: auto;width: 50%;display: block;')
                    .attr('src', 'assets/exp/' + this.explanation[this.storage.get('group') - 1][1]);
                figure
                    .append('video')
                    .attr('autoplay', true)
                    .attr('controls', true)
                    .attr('loop', true)
                    //.attr('width', 600)
                    //.attr('height', 400)
                    .attr('src', 'assets/exp/' + this.explanation[this.storage.get('group') - 1][0]);
                break;
            case 2:
                exp
                    .insert('img', 'p:nth-child(2)')
                    .attr('height', 'auto')
                    .attr('src', 'assets/exp/' + this.explanation[this.storage.get('group') - 1])
                    .attr('style', 'margin-left: auto;margin-right: auto;width: 75%;display: block;')
                break;
            case 3:
            case 4:
                exp
                    .insert('img', 'p')
                    .attr('height', 'auto')
                    .attr('src', 'assets/exp/' + this.explanation[this.storage.get('group') - 1])
                    .attr('style', 'margin-left: auto;margin-right: auto;width: 50%;display: block;');
                break;
        }

        d3.select(`#explanation-${this.storage.get('step')}`).select('.start-task').classed('is-loading', false);
        d3.select(`#task-${this.storage.get('step')}-text`).html(this.storage.get('text'));
    }

    nextTask() {
        const viz = new VizEvalFactory(this.storage.get('group'), `#figure-task-${this.getStep()}`)
        viz.attach(this.payloads[this.storage.get('group')])
        viz.changeMethod(this.storage.get('taskType'));
        // Error handling
    }

    hasData(key) {
        if (key in this.dataset) return true
        else return false
    }


    getFormData() {
        const formData = {};

        function getValue(selector) {
            const val = document.querySelector(selector) ? document.querySelector(selector).value : null;
            return val
        }

        formData['age'] = getValue('#age');
        formData['sex'] = getValue('#select-sex');
        formData['occ'] = getValue('#select-occupation');
        formData['vizexp'] = getValue('input[name="vizexp"]:checked');
        formData['referer'] = window.location.pathname.split('/')[1];

        // DEBUG
        formData['debug'] = getValue('#debug');


        return (formData)
    }

    validateForm() {

        // Rules
        // age > 16 < 100
        // vizexp != ''
        function getValue(selector) {
            const val = document.querySelector(selector) ? document.querySelector(selector).value : null;
            return val
        }
        const age = getValue('#age');
        if (!(age && age < 100 && age > 15))
            return 1;

        const vizexp = getValue('input[name="vizexp"]:checked')
        if (!(vizexp))
            return 1;

        return 0;
    }


    signup() {
        // error handling like its 1970
        const formValid = this.validateForm();
        if (formValid !== 0) {
            return formValid;
        }
        function setSignup(data, that) {
            that.storage.set('group', data.user.group_id + 1);
            that.storage.set('user', data.user.user_id);
            that.storage.set('token', data.user.token);
            that.storage.set('taskType', data.task['task_type'])
            that.storage.set('step', 0)
            that.setStep(0);
            that.currentState = 'taskState';
            that.currentState = 'firstTask';

            that.storage.set('taskType', data.task.task_type);
            that.storage.set('explanation', data.task.explanation);
            that.storage.set('text', data.task.text)
            that.updateTaskText();
        }
        const user = this.getFormData();
        const that = this;
        d3.json(baseURL + 'start/', {
            method: 'POST', headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }, body: JSON.stringify(user)
        })
            .then(data => setSignup(data, this))
        return 0
    }



    setStep(step) {
        this.storage.set('step', step);
    }
    getStep() {
        return this.storage.get('step');
    }
}
