import os
from flask_migrate import Migrate, MigrateCommand
from flask_script import Manager
from app import db, create_app
from app import models
from app.models import Task
from csv import DictReader
from app.config import app_config

app = create_app(config_name=os.getenv('APP_SETTINGS'))
app.config.from_object(app_config['development'])
app.config.from_pyfile('config.py')


migrate = Migrate(app, db)
manager = Manager(app)

manager.add_command('db', MigrateCommand, render_as_batch=True)

@manager.command
def reload_tasks():
    """Command to reload tasks from tasks.csv file
    """
    Task.query.delete()
    with open('tasks.csv', 'r') as file:
        reader = DictReader(file)
        for entry in reader:
            task = (Task(
                group_id=entry.get('group_id'),
                task_type=entry.get('task_type'),
                name=entry.get('task_name'),
                text=entry.get('task_text'),
                explanation=entry.get('explanation'),
                explanation_path=entry.get('explanation_path')
            ))
            task.save()        
            
    


if __name__ == '__main__':
    manager.run()
