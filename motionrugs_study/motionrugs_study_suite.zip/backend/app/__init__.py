from flask import Flask, jsonify, Response, stream_with_context, request, render_template
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from random import randint, choice
from csv import DictReader
from itertools import islice
from .config import app_config
import json
from functools import wraps
import os
from datetime import datetime


db = SQLAlchemy()


def create_app(config_name):
    from .models import Task, User, Tracking
    app = Flask(__name__, static_url_path='', static_folder='static', template_folder='static')
    # TODO: check for production environment
    CORS(app)
    app.config.from_object(app_config[config_name])
    app.config.from_pyfile('config.py')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)

    def need_authorization(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            auth = request.headers.get('Authorization')
            if auth:
                token = auth
            else:
                token = ''
            if token:
                user_id = User.decode_token(token)
                if not isinstance(user_id, str):
                    user = User.query.filter_by(id=user_id).first()
                    if user:
                        return f(*args, **kwargs, user=user)
                    else:
                        return jsonify({'error': 'User not found'}), 404
            else:
                return jsonify({'error': 'No valid token'}), 401
        return decorated_function

    @app.route('/start/', methods=['POST'])
    def submit_consent():

        req = request.get_json()
        if req.get('debug'):
            next_group = int(req.get('debug'))
        else:
            next_group = randint(0, 3)

        #next_type = randint(0, 4)
        # TODO: maybe use constants file?
        next_type = 99

        task = Task.query.filter_by(
            group_id=next_group, task_type=next_type).first()

        #TODO: screen_res = request.get_json()
        user = User(
            age=req.get('age'),
            sex=req.get('sex'),
            occupation=req.get('occ'),
            viz_experience=req.get('vizexp'),
            referer=req.get('referer'),
            current_task_id=task.id,
            current_step=0
        )
        user.group_id = next_group
        #TODO: user.screen_resolution = screen_res.get('screen_res')
        user.save()
        _user = user.to_json()
        _user['token'] = user.encode_token(user.id).decode()

        task = task.to_json()
        task['next_group'] = next_group

        resp = {'task': task, 'user': _user}
        return jsonify(resp), 201

    @app.route('/next/<int:group>/<int:seq>/', methods=['GET'])
    def get_next_task(group, seq):
        if not group or group < 1 or group > 4:
            return jsonify({'error': 'Group out of bounds'}), 400
        if not seq or seq < 1 or seq > 3:
            return jsonify({'error': 'Sequence out of bounds'}), 400
        try:
            task = Task.query.filter_by(group_id=group, seq=seq)
            return jsonify(task.first().to_json()), 200
        except:
            return jsonify({'error': 'Task not found'}), 404

    @app.route('/movement_data', methods=['GET'])
    def stream_movement_data():
        def stream():
            with open('app/data/st_mov_speed.csv', 'r') as file:
                reader = DictReader(file)
                while True:
                    # 4078 = 1% chunks
                    pos = list(islice(reader, 4078))
                    if not pos:
                        break
                    yield f'data: {json.dumps(pos, separators=(",",":"))}\n\n'
                yield 'data: close\n\n'
        return Response(stream_with_context(stream()), mimetype='text/event-stream')

    @app.route('/test_data', methods=['GET'])
    def stream_test_data():
        def stream():
            with open('app/data/test_mov_speed.csv', 'r') as file:
                reader = DictReader(file)
                while True:
                    # 2870 = 1% chunks
                    pos = list(islice(reader, 2870))
                    if not pos:
                        break
                    yield f'data: {json.dumps(pos, separators=(",",":"))}\n\n'
                yield 'data: close\n\n'
        return Response(stream_with_context(stream()), mimetype='text/event-stream')

    @app.route('/submit/', methods=['POST'])
    @need_authorization
    def submit_tracking(user):
        # TODO: Sanity checks
        # how many submissions?
        if user.current_step >= 6:
            return jsonify({'error': 'Session has concluded.'}), 403

        # payload size
        # is payload of correct format?

        req = request.get_json()
        tracking = Tracking(
            task_id=user.current_task_id,
            start_time=datetime.utcfromtimestamp(req.get('start')/1000),
            end_time=datetime.utcfromtimestamp(req.get('end')/1000),
            away_time=req.get('away'),
            user_id=user.id,
            task_sequence=user.current_step,
            task_data=req.get('payload')
        )

        tracking.save()

        tasks_completed = [
            i.task_id for i in Tracking.query.filter_by(user_id=user.id).all()]

        # exclude 99 which are fixed test tasks
        tasks_remaining = Task.query.filter_by(group_id=user.group_id).filter(
            Task.id.notin_(tasks_completed)).all()

        if len(tasks_remaining) == 0:
            return jsonify(None), 201

        # Draw new task
        next_task = choice(tasks_remaining)

        user.current_step += 1
        user.current_task_id = next_task.id
        user.save()

        return jsonify(next_task.to_json()), 201

    @app.route('/', methods=['GET'])
    def home():
        return render_template('index.html')

    return app
