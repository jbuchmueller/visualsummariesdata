from app import db
from datetime import datetime, timedelta
from sqlalchemy.event import listen
from sqlalchemy import CheckConstraint

import jwt
import os

TASK_TEST, TASK_ANIMATION, TASK_MOTIONRUG, TASK_MULTIPLE, TASK_STREAMLINE = range(5)


class Task(db.Model):
    """Represent the types of tasks including descriptions to be displayed and 
    additional data needed to solve, e.g. images"""

    __tablename__ = 'tasks'

    id = db.Column(db.Integer, primary_key = True)
    group_id = db.Column(db.Integer, nullable = False)
    task_type = db.Column(db.Integer, nullable = False)
    name = db.Column(db.String(255))
    explanation = db.Column(db.Text)
    text = db.Column(db.Text)
    tracking_data = db.relationship('Tracking', backref = 'tracking_data', lazy = True)
    explanation_path = db.Column(db.String(255))

    def save(self):
        db.session.add(self)
        db.session.commit()
    
    def to_json(self):
        return {
            'group_id': self.group_id,
            'task_type': self.task_type,
            'title': self.name,
            'explanation': self.explanation,
            'explanation_path': self.explanation_path,
            'text': self.text
        }


    @staticmethod
    def get_all():
        return Task.query.all()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    def __repr__(self):
        return f'<Task: {self.id} in group {self.group_id} of type {self.task_type}>'

OCCUPATION_STUDENT_BA, OCCUPATION_STUDENT_MA, OCCUPATION_RESEARCHER, OCCUPATION_OTHER = range(4)

class User(db.Model):
    """Holds tracking data at the user level"""
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key = True)
    group_id = db.Column(db.Integer, nullable = False)
    # TODO: Size limits? Validation?
    screen_resolution = db.Column(db.Text)
    start_date = db.Column(db.DateTime, nullable = False, default = datetime.now)
    age = db.Column(db.Integer, CheckConstraint('age>15'))
    sex = db.Column(db.Text)
    occupation = db.Column(db.Integer)
    bachelor_student = db.Column(db.Boolean)
    viz_experience = db.Column(db.Integer)
    referer = db.Column(db.Text)
    current_task_id = db.Column(db.Integer)
    current_step = db.Column(db.Integer)


    def encode_token(self, user_id):
        try:
            payload = {
                'exp': datetime.utcnow() + timedelta(hours = 4),
                'sub': user_id,
                'iat': datetime.utcnow() # time of generation
            }
            return jwt.encode(
                payload, 
                os.getenv('SECRET'),
                algorithm = 'HS256'
            )
        except Exception as e:
            return e

    @staticmethod
    def decode_token(auth_token):
        try:
            payload = jwt.decode(auth_token, os.getenv('SECRET'),
            algorithms= 'HS256')
            return payload['sub']
        except jwt.ExpiredSignatureError:
            return 'Token expired. Please start a new Session.'
        except jwt.InvalidTokenError:
            return 'Token is invalid. Please start a new Session.'

    def save(self):
        db.session.add(self)
        db.session.commit()
    
    def to_json(self):
        return {'group_id': self.group_id, 'user_id': self.id, 'step': self.current_step}

    @staticmethod
    def get_all():
        return Task.query.all()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    def __repr__(self):
        return f'<User: {self.id} in group {self.group_id}>'

    

class Tracking(db.Model):
    """Stores tracking data on a task level"""

    __tablename___ = 'tracking_data'

    id = db.Column(db.Integer, primary_key = True)
    task_id = db.Column(db.Integer, db.ForeignKey('tasks.id'), nullable = False)
    start_time = db.Column(db.DateTime, nullable = False)
    end_time = db.Column(db.DateTime, nullable = False)
    #TODO: ms or s?
    away_time = db.Column(db.Integer, nullable = False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable = False)
    date = db.Column(db.DateTime, nullable = False, default = datetime.utcnow)
    # 0 indexed
    task_sequence = db.Column(db.Integer)
    task_data = db.Column(db.JSON)

    def save(self):
        db.session.add(self)
        db.session.commit()
    

    @staticmethod
    def get_all():
        return Task.query.all()

    def delete(self):
        db.session.delete(self)
        db.session.commit()

    def __repr__(self):
        return f'<Tracking task {self.task_id} for user {self.user_id}>'