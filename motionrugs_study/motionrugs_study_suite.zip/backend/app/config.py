import os

class Config(object):
    """ Parent configuration class """
    DEBUG = True
    CSRF_ENABLED = True
    SECRET = os.getenv('SECRET')
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL')

class DevelopmentConfig(Config):
    DEBUG = True

class TestingConfig(Config):
    """Use separate DB for testing"""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///mr_test.db'
    DEBUG = True

class ProductionConfig(Config):
    DEBUG = False
    TESTING = False


app_config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig
}

