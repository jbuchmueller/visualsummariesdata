import unittest
import os
import json
from datetime import datetime

from app import create_app, db
from app.models import Task, User


class UserTestCase(unittest.TestCase):
    
    def setUp(self):
        self.app = create_app(config_name='testing')
        self.client = self.app.test_client

        self.test_user = {'screen_res': '2560x1440', 'ip_address': '127.0.0.1'} 
        test_task = Task(group_id=0, title='Test Task',
                         text='This task is for testing purposes only. Please click anywhere')

        with self.app.app_context():
            db.create_all()
            test_task.save()    
    

    def test_create_new_user(self):
        res = self.client().post(
                '/start/',
                data = json.dumps(dict(
                    screen_res='2560x1440',
                    ip_address='127.0.0.1'
                )),
                content_type = 'application/json'
            )
        data = json.loads(res.data).get('user')
        self.assertEqual(res.status_code, 201)
        self.assertEqual(data['user_id'], 1)
        self.assertTrue(data['token'])
        self.token = data['token']

    def test_authorized_submission(self):
        res = self.client().post(
                '/start/',
                data = json.dumps(dict(
                    screen_res='2560x1440',
                    ip_address='127.0.0.1'
                )),
                content_type = 'application/json'
            )
        user_data = json.loads(res.data).get('user')

        res = self.client().post(
            '/submit/',
            headers = dict(
                Authorization = 'Bearer ' + user_data['token']
            ),
            data = dict(
                start_time = datetime.now(),
                end_time = datetime.now(),
                away_time = 200,
                task_sequence = 0
            )
        )

        data = json.loads(res.data.decode())
        self.assertEqual(res.status_code, 201)
        self.assertEqual(data['user_id'], user_data['user_id'])
        print(data)


    def test_no_valid_token(self):
        res = self.client().post(
                '/start/',
                data = json.dumps(dict(
                    screen_res='2560x1440',
                    ip_address='127.0.0.1'
                )),
                content_type = 'application/json'
            )
        user_data = json.loads(res.data).get('user')
        res = self.client().post(
            '/submit/',
            data = dict(
                task_id = 1
            )
        )

        data = json.loads(res.data.decode())
        self.assertEqual(res.status_code, 401)
        self.assertEqual(data['error'], 'No valid token')



    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()


if __name__ == '__main__':
    unittest.main()
