import unittest
import os
import json

from app import create_app, db
from app.models import Task


class TaskTestCase(unittest.TestCase):

    def setUp(self):
        self.app = create_app(config_name='testing')
        self.client = self.app.test_client

        test_task = Task(group_id=0, title='Test Task',
                         text='This task is for testing purposes only. Please click anywhere')

        real_task = Task(group_id=2, title='Real Task', seq=1,
                         text='This is a real task in which we test a real Viz. Plese identify\
            some pattern here')

        real_task2 = Task(group_id=2, title='Second Task', seq=2,
                          text='This is another task in which we test a real Viz. Plese identify\
            some pattern here')

        self.test_user = {'screen_res': '2560x1440', 'ip_address': '127.0.0.1'} 

        with self.app.app_context():
            db.create_all()
            test_task.save()
            real_task.save()
            real_task2.save()

    def test_submit_consent(self):
        res = self.client().post('/start/')
        dic = {'group_id': 0, 'title': 'Test Task',
               'text': 'This task is for testing purposes only. Please click anywhere',
               'picture': None}
        self.assertEqual(res.status_code, 201)
        resp = json.loads(res.data).get('task')
        self.assertDictContainsSubset(dic, resp)
        self.assertIn('next_group', resp)
        self.assertGreater(resp['next_group'], 0)

    def test_get_first_task(self):
        res = self.client().get('/next/2/1/')
        dic = {'group_id': 2, 'title': 'Real Task', 'picture': None,
               'text': 'This is a real task in which we test a real Viz. Plese identify\
            some pattern here'}
        self.assertEqual(res.status_code, 200)
        resp = json.loads(res.data)
        self.assertDictEqual(dic, resp)

    def test_get_second_task(self):
        res = self.client().get('/next/2/2/')
        dic = {'group_id': 2, 'title': 'Second Task', 'picture': None,
               'text': 'This is another task in which we test a real Viz. Plese identify\
            some pattern here', 'picture': None}
        self.assertEqual(res.status_code, 200)
        resp = json.loads(res.data)
        self.assertDictEqual(dic, resp)

    def test_task_not_there(self):
        res = self.client().get('/next/3/2/')
        self.assertEqual(res.status_code, 404)

        res = self.client().get('/next/3/5/')
        self.assertEqual(res.status_code, 400)

        res = self.client().get('/next/0/1/')
        self.assertEqual(res.status_code, 400)

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()


if __name__ == '__main__':
    unittest.main()
