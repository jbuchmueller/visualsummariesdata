# Helper program to generate a .env file for use with flask
import os
params = ["FLASK_APP='run.py'"]

_settings = "development"
settings = input("Which settings to use? ([development]/production):")
if settings == "":
    settings = "APP_SETTINGS='" + _settings + "'"
else:
     settings = "APP_SETTINGS='" + settings + "'"
params.append(settings)

secret = ''
while(secret == ''):
    secret = input("Please enter a secret (some random phrase or combination of symbols):")
if secret != "":
    params.append("SECRET='" + secret + "'")

_path = 'sqlite:///' + os.path.join(os.path.split(os.path.abspath(__file__))[0], 'motionrugs.db')
database = input(f"If you want to change the standard location of the sqlite database, enter it now ({_path}):")


_database = "DATABASE_URL='"
if database != "":
    _database += database + "'"
else: 
    _database +=  _path + "'" 

params.append(_database)



print("Writing to .env ...")

with open(".env", "w") as file:
    for p in params:
        file.write(p + "\n") 

print("Success")
