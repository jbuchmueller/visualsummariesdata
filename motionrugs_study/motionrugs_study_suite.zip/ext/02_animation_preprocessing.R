library(readr)
library(dplyr)

study <- read_csv('exampledata3600-5500.csv') %>%
  select(t = frame, a = id, x, y, speed) %>%
  # calculate deciles, round to two signifcants to reduce filesize
  mutate(s = ntile(speed, 10), x = round(x, 2), y = round(y, 2)) %>%
  select(-speed)

write_csv(study, '../backend/app/data/test_mov_speed.csv')


study <- read_csv('studydata10300-13000.csv') %>%
  select(t = frame, a = id, x, y, speed) %>%
  # calculate deciles, round to two signifcants to reduce filesize
  mutate(s = ntile(speed, 10), x = round(x, 2), y = round(y, 2)) %>%
  select(-speed)

write_csv(study, '../backend/app/data/st_mov_speed.csv')
