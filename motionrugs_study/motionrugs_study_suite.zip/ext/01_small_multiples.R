library(tidyverse)
library(ggforce) # facet_wrap_paginate

test_shiner <- read_csv("exampledata3600-5500.csv")  %>%
  group_by(id) %>% 
  mutate(x2 = lag(x), y2=lag(y)) %>% 
  mutate(speed2 = sqrt((x-x2)^2+(y-y2)^2)) %>%
  mutate(speed2 = pmax(pmin(speed2, 25), 1), interval = frame %/% 250) %>%
  mutate(s = ntile(speed, 10))

eval_shiner <- read_csv("studydata10300-13000.csv")  %>%
  group_by(id) %>% 
  mutate(x2 = lag(x), y2=lag(y)) %>% 
  mutate(speed2 = sqrt((x-x2)^2+(y-y2)^2)) %>%
  mutate(speed2 = pmax(pmin(speed2, 25), 1), interval = frame %/% 250) %>%
  mutate(s = ntile(speed, 10))



stream <- list()


streamlines <- function(shiner, prefix) {
  step_size <- round(length(unique(shiner$frame))/24)
  
  for(i in 1:24) {
      plt <- 
      ggplot(shiner) +
      aes(x=y, y=x, color=s, group=id) +
      geom_path(size=1, alpha=0.66) +
      geom_point(data = shiner %>% filter(frame %% step_size == step_size-1), size = 2) +
      scale_color_gradientn(colors=rev(RColorBrewer::brewer.pal(10, 'RdYlBu'))) +
      facet_wrap_paginate(~(frame %/% step_size), 1, 1, page=i) +
      theme_bw() +
        theme(panel.spacing.x = unit(0, 'mm'),
              axis.text.x = element_blank(),
              axis.text.y = element_blank(),
              axis.ticks = element_blank(),
              strip.text = element_blank(),
              axis.title = element_blank(),
              legend.position = 'none',
              panel.grid.major = element_blank(),
              panel.grid.minor = element_blank()
              )
      ggsave(paste0('output/', prefix ,'_streamline_', i, '.png'), plt, width = 7.5, height = 7.5, dpi = 150)
  }
}

streamlines(test_shiner, 'test')
streamlines(eval_shiner, 'eval')




# This code needs serious optimization....
generate_triangle <- function(.data) {
  asd <<- .data
  trihard <- function(deg, x, y) {
    #angle <- ((deg * pi)/180)
    angle  <-  deg
    data.frame(
      x = c(
        cos(angle)*50 + x,
        cos(angle+90)*16 + x,
        cos(angle-90)*16 + x
      ),
      y = c(
        sin(angle)*50 + y,
        sin(angle+90)*16 + y,
        sin(angle-90)*16 + y
      ))
  }
  
  tris <- data.frame(frame = integer(), id = integer(), x = double(), y = double(), speed = double(), s = double())
  num_rows_behind <- length(unique(.data$id))
  #print(num_rows_behind)
    for(i in 1:nrow(.data)) {
      #print(i)
      if(i > num_rows_behind) {
        lagged <- .data[i - num_rows_behind, ]
        
      } else {
        lagged <- .data[i + num_rows_behind, ]
      }
      #print(.data[i,]$y)
      #print(lagged$y)
      # get angle of movement between frames
      mid <- trihard(
        atan2(.data[i,]$y - lagged$y, .data[i,]$x - lagged$x), .data[i,]$x, .data[i,]$y)
      mid$speed <- .data[i,]$speed
      mid$id <- .data[i,]$id
      mid$frame <- .data[i,]$frame
      mid$s <- .data[i,]$s
      tris <- rbind(tris, mid)
  }

  return(tris)
  
}

triangles <- function(shiner, prefix) {
  step_size <- floor(length(unique(shiner$frame))/24)
  
  
  tri_data <- shiner %>%
    filter(frame %% step_size == step_size-1) %>%
    generate_triangle()
  
  for(i in 1:24) {
    tri <- 
      ggplot(shiner) +
      aes(x=y, y=x, fill=s, group=id) +
      geom_polygon(data = tri_data) +
      scale_fill_gradientn(colors=rev(RColorBrewer::brewer.pal(10, 'RdYlBu'))) +
      facet_wrap_paginate(~(frame %/% step_size), 1, 1, page=i) +
      theme_bw() +
      theme(panel.spacing.x = unit(0, 'mm'),
            axis.text.x = element_blank(),
            axis.text.y = element_blank(),
            axis.ticks = element_blank(),
            strip.text = element_blank(),
            axis.title = element_blank(),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            legend.position = 'none')
    ggsave(paste0('output/', prefix ,'_multiples_', i, '.png'), tri, width = 7.5, height = 7.5, dpi = 300)
    
  }
  
}


triangles(eval_shiner, 'eval')
triangles(test_shiner, 'test')
