
# load data, label shoal/fish, scale timesteps
directory = "~/data/motionrug-small-multiples/Data Dryad/"

filenames = dir(directory)
data = lapply(filenames, function(x) {read.csv(paste0(directory, x)) %>% mutate(name=x)})
data = lapply(data, function(x) {names(x)=c('x', 'y', 'z', 'time', 'fish'); x})
data = bind_rows(data)
data = data %>% 
  separate(fish, c('shoal', 'fish'), '_') %>%
  mutate(time = (time - 0.03125)/0.03125)

# compute speed
data = data %>% 
  group_by(fish, shoal) %>% 
  mutate(x2 = lag(x), y2=lag(y)) %>% 
  mutate(speed = sqrt((x-x2)^2+(y-y2)^2)) %>%
  mutate(speed = pmax(pmin(speed, 25), 1))
# the final timestep has no speed
data$speed[data$time == 999] = data$speed[data$time == 998]

# visualize
ggplot(data) +
  aes(x, y, color=speed, group=fish) +
  geom_path(size=1, alpha=0.66) +
  geom_point(data = data %>% filter(time %% 125 == 124), size = 2) +
  scale_color_gradientn(colors=rev(RColorBrewer::brewer.pal(10, 'RdYlBu'))) +
  facet_grid(shoal ~ (time %/% 125)) +
  theme_bw() +
  theme(panel.spacing.x = unit(0, 'mm'))

#shiner <- read_csv("fishdatashort.csv")  %>%
shiner <- read_csv("studydata10300-13000.csv")  %>%
  group_by(id) %>% 
  mutate(x2 = lag(x), y2=lag(y)) %>% 
  mutate(speed2 = sqrt((x-x2)^2+(y-y2)^2)) %>%
  mutate(speed2 = pmax(pmin(speed2, 25), 1), interval = frame %/% 250)


streamlines <- 
  shiner %>% 
  ggplot() +
  aes(x, y, color=speed, group=id) +
  geom_path(size=1, alpha=0.66) +
  geom_point(data = shiner %>% filter(frame %% 250 == 249), size = 2) +
  scale_color_gradientn(colors=rev(RColorBrewer::brewer.pal(10, 'RdYlBu'))) +
  facet_wrap_paginate(~(frame %/% 250), 1, 1, page=1) +
  theme_bw() +
  theme(panel.spacing.x = unit(0, 'mm'),
        axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks = element_blank(),
        strip.text = element_blank(),
        axis.title = element_blank(),
        legend.position = 'none')



### NIcht benutzen ---- 

shiner %>% filter(id < 11) %>%
  ggplot() +
  aes(x, y, color=speed, group=id) +
  geom_path(size=1, alpha=0.66) +
  geom_point(data = shiner %>% filter(id < 11, frame %% 250 == 249), size = 2) +
  scale_color_gradientn(colors=rev(RColorBrewer::brewer.pal(10, 'RdYlBu'))) +
  facet_grid(id ~ (frame %/% 250)) +
  theme_bw() +
  theme(panel.spacing.x = unit(0, 'mm'))

shiner <- shiner %>% mutate(
  gr = case_when(
    id < 9 ~ 1,
    id < 19 ~ 2,
    id < 29 ~ 3,
    id < 39 ~ 4,
    id < 49 ~ 5,
    id < 59 ~ 6,
    id < 69 ~ 7,
    id < 79 ~ 8,
    id < 89 ~ 9,
    id < 99 ~ 10,
    id < 109 ~ 11,
    id < 119 ~ 12,
    id < 129 ~ 13,
    TRUE ~ 14
  )
)
shiner %>% filter(id < 76, frame < 1001) %>%
  ggplot() +
  aes(x, y, color=speed, group=gr) +
  geom_path(size=1, alpha=0.66) +
  geom_point(data = shiner %>% filter(frame < 1001, id < 76, frame %% 250 == 248), size = 2) +
  scale_color_gradientn(colors=rev(RColorBrewer::brewer.pal(10, 'RdYlBu'))) +
  facet_grid(gr ~ (frame %/% 250)) +
  theme_bw() +
  theme(panel.spacing.x = unit(0, 'mm'))




small_multiples <- 
  shiner2 %>% 
  ggplot() +
  aes(x, y, color=speed, group=id) +
  geom_point(data = shiner2 %>% filter(frame %% 250 == 249), size = 2) +
  scale_color_gradientn(colors=rev(RColorBrewer::brewer.pal(10, 'RdYlBu'))) +
  facet_wrap(~(frame %/% 250)) +
  theme_bw() +
  theme(panel.spacing.x = unit(0, 'mm'))

ggsave("shiner_streamlines.png", streamlines, width = 15, height = 13, dpi = 300)
ggsave("small_multiples.png", small_multiples, width = 15, height = 13, dpi = 300)


